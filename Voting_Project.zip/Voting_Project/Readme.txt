VotingSystem01.java is basic code without Multi-Threading

VotingSystem02.java is program with Multi-Threading


All class files are placed into respective packages in package "votingproject"

to create u r own class files in packages please use " javac -d . programName.java "

**************************************************************************************************************************************************************************************************
// written by 5c1
please change the class name VotingSystem01 to "VotingSystem"

also change the code file name from "VotingSystem01.java" to "VotingSystem.java"


1 . Please run "PoliticalParty.java" --> to create the package votingproject and PoliticalParty - class file
2 . Now run Party1 Party2 Party3 Party4 and NOTA.java files to create their respective class files in package "votingproject"
3 . Now run "VotingSystem.java"


Got errors.......? :crying_with_laugh_emoji:
try running this first: " javac votingproject.* "   // this creates all class files to the .java files in package if in case u move all files from their packages to single 'votingproject' folder

Now " java VotingSystem "
// that works in case u just unzipped file and forgot to change directory to votingproject folder

in case ur in same dirrectory as all .java files i.e ur in votingproject folder try the following:
" javac Politicalparty.java Party1.java Party2.java Party3.java Party4.java NOTA.java  "
and then 
" javac VotingSystem.java " // dont forget to check directory carefully 
" java VotingSystem "

please leave " VotingSystem.java " out side the package.

Hopefully the proram outputs the data to the text file. Don't forget to check the .txt file after execution.


Why don't you try to debug the errors on your own if any?

in case if u still have errors message ya 

this project has multiple packages so create carefully yaar 


TAKE CARE 
TATA BYE BYE
c ya.

218w1a05c1@vrsec.ac.in