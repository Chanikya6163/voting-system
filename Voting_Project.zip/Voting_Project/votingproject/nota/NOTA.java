package votingproject.nota;

import votingproject.PoliticalParty;

public class NOTA extends PoliticalParty 
{
    public NOTA() 
    {
        super("NOTA", "None");
    }
}
