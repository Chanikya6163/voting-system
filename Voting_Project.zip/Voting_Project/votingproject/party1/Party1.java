package votingproject.party1;

import votingproject.PoliticalParty;

public class Party1 extends PoliticalParty 
{
    public Party1() 
    {
        super("Party 1", "Red");
    }
}
