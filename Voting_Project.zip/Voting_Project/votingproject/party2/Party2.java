package votingproject.party2;

import votingproject.PoliticalParty;

public class Party2 extends PoliticalParty 
{
    public Party2() 
    {
        super("Party 2", "Green");
    }
}
