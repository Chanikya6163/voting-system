package votingproject.party3;

import votingproject.PoliticalParty;

public class Party3 extends PoliticalParty 
{
    public Party3() 
    {
        super("Party 3", "Blue");
    }
}
