package votingproject.party4;

import votingproject.PoliticalParty;

public class Party4 extends PoliticalParty 
{
    public Party4() 
    {
        super("Party 4", "Yellow");
    }
}
